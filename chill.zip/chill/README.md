# Chill

## Flutter Tinder Clone built with Firebase and Bloc

## [Youtube Tutorial Series Explaining How App Was Built](https://www.youtube.com/watch?v=uSck9FC-b9g&list=PLdBY1aYxSpPVokznNKIg3dmdeeJHiHF9Z)

<img height="700" src="https://github.com/OdongoWaga/chill/blob/master/Screenshot%202020-05-12%20at%2008.52.48.png" />
<img height="700" src="https://github.com/OdongoWaga/chill/blob/master/Screenshot%202020-05-12%20at%2009.03.41.png" />

